﻿using System;
using System.CodeDom.Compiler;
using System.Xml.Serialization;


namespace Architecture_Construct
{
    [Serializable]
    public abstract class Employee
    {
        ///attributes
        private string employeeID;
        private string employeeName;
        private string checkIn;
        private string checkOut;
        private string equipmentAvailable;

        //constructors
        public Employee()
        {
            employeeID = "ID";
            employeeName = "N/A";
            checkIn = "N/A";
            checkOut = "N/A";
            equipmentAvailable ="Equipment Available" ;
        }
        public Employee(string employeeID, string employeeName, string checkIn, string checkOut, string equipmentAvailable)
        {
            this.employeeID = employeeID;
            this.employeeName = employeeName;
            this.checkIn = checkIn;
            this.checkOut = checkOut;
            this.equipmentAvailable = equipmentAvailable;
        }

        //behaviors
        public override string ToString()
        {
            return "Employee ID: " + employeeID + ", Name: " + employeeName 
                + ", Equipment Check In: " + checkIn + ", Equipment Check Out: " + checkOut
                + ", Number of Available Equipment:" + equipmentAvailable;
        }
        
        //properties
        public string EmployeeID
        {
            get { return employeeID; }
            set => employeeID = value;  //employee.employeeID = "0013"
        }

        public string Name
        {
            get { return employeeName; }
            set { employeeName = value; }
        }

        public string CheckIn
        {
            get { return checkIn; }
            set { checkIn = value; }
        }

        public string CheckOut
        {
            get { return checkOut; }
            set { checkOut = value; }
        }

        public string EquipmentAvailable
        {
            get { return equipmentAvailable; }
            set { equipmentAvailable = value; }
        }
    }
 }
