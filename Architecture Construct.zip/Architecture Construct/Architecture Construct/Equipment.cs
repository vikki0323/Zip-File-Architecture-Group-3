﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Architecture_Construct
{
    public abstract class Equipment
    {
        ///attributes
        private string employeeID;
        private string checkIn;
        private string checkOut;
        private string equipmentAvailable;

        //constructors
        public Equipment()
        {
            employeeID = "ID";
            checkIn = "N/A";
            checkOut = "N/A";
            equipmentAvailable = "Equipment Available";
        }
        public Equipment(string employeeID, string checkIn, string checkOut, string equipmentAvailable)
        {
            this.employeeID = employeeID;
            this.checkIn = checkIn;
            this.checkOut = checkOut;
            this.equipmentAvailable = equipmentAvailable;
        }

        //behaviors
        public override string ToString()
        {
            return "Employee ID: " + employeeID + ", Equipment Check In: " + checkIn + ", Equipment Check Out: " + checkOut
                + ", Number of Available Equipment:" + equipmentAvailable;
        }

        //properties
        public string EmployeeID
        {
            get { return employeeID; }
            set => employeeID = value;  //employee.employeeID = "0013"
        }

        public string CheckIn
        {
            get { return checkIn; }
            set { checkIn = value; }
        }

        public string CheckOut
        {
            get { return checkOut; }
            set { checkOut = value; }
        }

        public string EquipmentAvailable
        {
            get { return equipmentAvailable; }
            set { equipmentAvailable = value; }
        }
    }
}
