﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Architecture_Construct
{
    public abstract class Supervisor
    {
        ///attributes
        private string employeeID;
        private string employeeName;
        private string checkIn;
        private string checkOut;
        private DateTime dateTime;
        private string equipmentAvailable;
        private DateTime terminationDate;

        //constructors
        public Supervisor()
        {
            employeeID = "ID";
            employeeName = "N/A";
            checkIn = "N/A";
            checkOut = "N/A";
            dateTime = terminationDate;
            equipmentAvailable = "Equipment Available";
        }
        public Supervisor(string employeeID, string employeeName, string checkIn, string checkOut, string equipmentAvailable, DateTime dateTime, DateTime terminationDate)
        {
            this.employeeID = employeeID;
            this.employeeName = employeeName;
            this.checkIn = checkIn;
            this.checkOut = checkOut;
            this.dateTime = terminationDate;
            this.equipmentAvailable = equipmentAvailable;
        }

        //behaviors
        public override string ToString()
        {
            return "Employee ID: " + employeeID + ", Name: " + employeeName
                + ", Equipment Check In: " + checkIn + ", Equipment Check Out: " + checkOut
                + ", Number of Available Equipment:" + equipmentAvailable + ",Termination Date: " + terminationDate;
        }

        //properties
        public string EmployeeID
        {
            get { return employeeID; }
            set => employeeID = value;  //employee.employeeID = "0013"
        }

        public string Name
        {
            get { return employeeName; }
            set { employeeName = value; }
        }

        public string CheckIn
        {
            get { return checkIn; }
            set { checkIn = value; }
        }

        public string CheckOut
        {
            get { return checkOut; }
            set { checkOut = value; }
        }

        public string EquipmentAvailable
        {
            get { return equipmentAvailable; }
            set { equipmentAvailable = value; }
        }

        public string TerminationDate
        {
            get { return TerminationDate; }
            set { TerminationDate = value; }
        }
    }
}
