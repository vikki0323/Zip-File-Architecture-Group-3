﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Architecture_Construct
{
    public abstract class Termination
    {
        ///attributes
        private string employeeID;
        private string checkIn;
        private string checkOut;
        private DateTime dateTime;
        private DateTime terminationDate;

        //constructors
        public Termination()
        {
            employeeID = "ID";
            checkIn = "N/A";
            checkOut = "N/A";
            dateTime = terminationDate;
        }
        public Termination(string employeeID, string employeeName, string checkIn, string checkOut, string equipmentAvailable, DateTime dateTime, DateTime terminationDate)
        {
            this.employeeID = employeeID;
            this.checkIn = checkIn;
            this.checkOut = checkOut;
            this.dateTime = terminationDate;
        }

        //behaviors
        public override string ToString()
        {
            return "Employee ID: " + employeeID + ", Equipment Check In: " + checkIn + ", Equipment Check Out: " + checkOut
                + ", Termination Date:" + terminationDate;
        }

        //properties
        public string EmployeeID
        {
            get { return employeeID; }
            set => employeeID = value;  //employee.employeeID = "0013"
        }

        public string CheckIn
        {
            get { return checkIn; }
            set { checkIn = value; }
        }

        public string CheckOut
        {
            get { return checkOut; }
            set { checkOut = value; }
        }

        public string TerminationDate
        {
            get { return TerminationDate; }
            set { TerminationDate = value; }
        }
    }   
}
